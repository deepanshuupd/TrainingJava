package com.hexaware.mainmodule;

import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.NegativeAmountException;

import java.util.ArrayList;


public class Main {
    public static void main(String[] args) {

        BankAccount obj1 = new BankAccount("Deepanshu", "Saving", 1000.00);
        ArrayList<BankAccount> myList = new ArrayList<>();
        myList.add(obj1);
        Bank myBank = new Bank("icici", myList);
        System.out.println(myBank);
        ServiceProviderImpl myServiceObj = new ServiceProviderImpl(myBank);
        try{
            System.out.println("Balance of account 1110 is " + myServiceObj.checkBalance(1110));

        }catch(AccountNumberInvalidException e){
            e.printStackTrace();

        }
        try{
            System.out.println("Status of deposit " + myServiceObj.deposit(+1110, 100.0));

        }catch(NegativeAmountException e){
            e.printStackTrace();
        }catch(AccountNumberInvalidException e){
            e.printStackTrace();
        }
        System.out.println("Status of account creation " + myServiceObj.createAccount(new BankAccount("Panu", "Current", 500.00)));
        try{
            System.out.println("Balance of account 1110 is " + myServiceObj.checkBalance(1111));

        }catch(AccountNumberInvalidException e){
            e.printStackTrace();

        }
    }
}

